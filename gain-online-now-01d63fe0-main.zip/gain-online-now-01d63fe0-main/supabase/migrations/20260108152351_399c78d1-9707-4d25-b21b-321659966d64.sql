-- First, update the referrals table to track bonus status better
ALTER TABLE public.referrals ADD COLUMN IF NOT EXISTS numbers_sold INTEGER DEFAULT 0;

-- Update the handle_new_user function to NOT give bonus immediately
CREATE OR REPLACE FUNCTION public.handle_referral_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  referrer_profile_id UUID;
  new_user_profile_id UUID;
BEGIN
  -- Get the new user's profile
  SELECT id INTO new_user_profile_id FROM public.profiles WHERE user_id = NEW.id;
  
  -- Check if user was referred
  IF NEW.raw_user_meta_data ->> 'referred_by' IS NOT NULL THEN
    -- Get referrer profile id from referral code
    SELECT id INTO referrer_profile_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data ->> 'referred_by';
    
    IF referrer_profile_id IS NOT NULL AND new_user_profile_id IS NOT NULL THEN
      -- Update referred_by in profile
      UPDATE public.profiles SET referred_by = referrer_profile_id WHERE id = new_user_profile_id;
      
      -- Create referral record with pending status (no bonus yet)
      INSERT INTO public.referrals (referrer_id, referred_id, bonus_amount, status, numbers_sold)
      VALUES (referrer_profile_id, new_user_profile_id, 5, 'pending', 0)
      ON CONFLICT (referred_id) DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Update process_referral_after_profile to NOT give bonus immediately
CREATE OR REPLACE FUNCTION public.process_referral_after_profile()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  referrer_profile_id UUID;
  referred_by_code TEXT;
BEGIN
  -- Get referral code from auth.users metadata
  SELECT raw_user_meta_data ->> 'referred_by' INTO referred_by_code
  FROM auth.users WHERE id = NEW.user_id;
  
  IF referred_by_code IS NOT NULL AND referred_by_code != '' THEN
    -- Get referrer profile
    SELECT id INTO referrer_profile_id FROM public.profiles WHERE referral_code = referred_by_code;
    
    IF referrer_profile_id IS NOT NULL THEN
      -- Update referred_by
      UPDATE public.profiles SET referred_by = referrer_profile_id WHERE id = NEW.id;
      
      -- Create referral record with pending status (no bonus yet)
      INSERT INTO public.referrals (referrer_id, referred_id, bonus_amount, status, numbers_sold)
      VALUES (referrer_profile_id, NEW.id, 5, 'pending', 0)
      ON CONFLICT (referred_id) DO NOTHING;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create function to check and give referral bonus when seller number is approved
CREATE OR REPLACE FUNCTION public.check_referral_bonus_on_seller_approval()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = 'public'
AS $$
DECLARE
  user_profile_id UUID;
  referrer_profile_id UUID;
  referrer_user_id UUID;
  approved_count INTEGER;
  bonus DECIMAL := 5;
BEGIN
  -- Only proceed if status changed to 'approved' and code_status is 'approved'
  IF NEW.status = 'approved' AND NEW.code_status = 'approved' AND 
     (OLD.code_status IS DISTINCT FROM 'approved') THEN
    
    -- Get user's profile id
    SELECT id INTO user_profile_id FROM public.profiles WHERE user_id = NEW.user_id;
    
    IF user_profile_id IS NOT NULL THEN
      -- Check if this user was referred and bonus not yet given
      SELECT referrer_id INTO referrer_profile_id 
      FROM public.referrals 
      WHERE referred_id = user_profile_id AND status = 'pending';
      
      IF referrer_profile_id IS NOT NULL THEN
        -- Count approved seller numbers with approved codes for this user
        SELECT COUNT(*) INTO approved_count 
        FROM public.seller_numbers 
        WHERE user_id = NEW.user_id 
          AND status = 'approved' 
          AND code_status = 'approved';
        
        -- Update numbers_sold count in referrals
        UPDATE public.referrals 
        SET numbers_sold = approved_count 
        WHERE referred_id = user_profile_id AND status = 'pending';
        
        -- If 2 or more approved, give bonus
        IF approved_count >= 2 THEN
          -- Get referrer's user_id
          SELECT user_id INTO referrer_user_id FROM public.profiles WHERE id = referrer_profile_id;
          
          -- Update referral status to completed
          UPDATE public.referrals 
          SET status = 'completed' 
          WHERE referred_id = user_profile_id;
          
          -- Give bonus to referrer
          UPDATE public.profiles 
          SET balance = balance + bonus 
          WHERE id = referrer_profile_id;
          
          -- Create transaction for referrer
          INSERT INTO public.transactions (user_id, type, amount, status, description)
          VALUES (referrer_user_id, 'referral_bonus', bonus, 'completed', 'Referral بونس - ۲ نمبره وپلورل شوې');
        END IF;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for seller number approval
DROP TRIGGER IF EXISTS check_referral_on_seller_approval ON public.seller_numbers;
CREATE TRIGGER check_referral_on_seller_approval
AFTER UPDATE ON public.seller_numbers
FOR EACH ROW
EXECUTE FUNCTION public.check_referral_bonus_on_seller_approval();