-- Create referrals tracking table
CREATE TABLE public.referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID NOT NULL REFERENCES public.profiles(id),
  referred_id UUID NOT NULL REFERENCES public.profiles(id),
  bonus_amount DECIMAL(10,2) NOT NULL DEFAULT 5,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(referred_id)
);

-- Enable RLS
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own referrals as referrer"
  ON public.referrals FOR SELECT
  USING (referrer_id IN (SELECT id FROM public.profiles WHERE user_id = auth.uid()));

CREATE POLICY "Admins can view all referrals"
  ON public.referrals FOR SELECT
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage referrals"
  ON public.referrals FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

-- Function to handle referral signup and give bonus
CREATE OR REPLACE FUNCTION public.handle_referral_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_profile_id UUID;
  new_user_profile_id UUID;
  bonus DECIMAL := 5;
BEGIN
  -- Get the new user's profile
  SELECT id INTO new_user_profile_id FROM public.profiles WHERE user_id = NEW.id;
  
  -- Check if user was referred
  IF NEW.raw_user_meta_data ->> 'referred_by' IS NOT NULL THEN
    -- Get referrer profile id from referral code
    SELECT id INTO referrer_profile_id 
    FROM public.profiles 
    WHERE referral_code = NEW.raw_user_meta_data ->> 'referred_by';
    
    IF referrer_profile_id IS NOT NULL AND new_user_profile_id IS NOT NULL THEN
      -- Update referred_by in profile
      UPDATE public.profiles SET referred_by = referrer_profile_id WHERE id = new_user_profile_id;
      
      -- Create referral record
      INSERT INTO public.referrals (referrer_id, referred_id, bonus_amount, status)
      VALUES (referrer_profile_id, new_user_profile_id, bonus, 'completed');
      
      -- Give bonus to referrer
      UPDATE public.profiles SET balance = balance + bonus WHERE id = referrer_profile_id;
      
      -- Create transaction for referrer
      INSERT INTO public.transactions (user_id, type, amount, status, description)
      SELECT user_id, 'referral_bonus', bonus, 'completed', 'Referral بونس - نوی کارکوونکی'
      FROM public.profiles WHERE id = referrer_profile_id;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create trigger for referral handling (after profile is created)
CREATE OR REPLACE FUNCTION public.process_referral_after_profile()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_profile_id UUID;
  referred_by_code TEXT;
  bonus DECIMAL := 5;
BEGIN
  -- Get referral code from auth.users metadata
  SELECT raw_user_meta_data ->> 'referred_by' INTO referred_by_code
  FROM auth.users WHERE id = NEW.user_id;
  
  IF referred_by_code IS NOT NULL AND referred_by_code != '' THEN
    -- Get referrer profile
    SELECT id INTO referrer_profile_id FROM public.profiles WHERE referral_code = referred_by_code;
    
    IF referrer_profile_id IS NOT NULL THEN
      -- Update referred_by
      UPDATE public.profiles SET referred_by = referrer_profile_id WHERE id = NEW.id;
      
      -- Create referral record
      INSERT INTO public.referrals (referrer_id, referred_id, bonus_amount, status)
      VALUES (referrer_profile_id, NEW.id, bonus, 'completed')
      ON CONFLICT (referred_id) DO NOTHING;
      
      -- Give bonus to referrer
      UPDATE public.profiles SET balance = balance + bonus WHERE id = referrer_profile_id;
      
      -- Create transaction
      INSERT INTO public.transactions (user_id, type, amount, status, description)
      SELECT user_id, 'referral_bonus', bonus, 'completed', 'Referral بونس'
      FROM public.profiles WHERE id = referrer_profile_id;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_profile_created_process_referral
  AFTER INSERT ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.process_referral_after_profile();