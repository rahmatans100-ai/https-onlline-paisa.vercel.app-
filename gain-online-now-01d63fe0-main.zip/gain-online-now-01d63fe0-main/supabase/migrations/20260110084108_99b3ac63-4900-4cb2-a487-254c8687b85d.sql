-- Create admin_notifications table for admin alerts
CREATE TABLE public.admin_notifications (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL, -- 'new_user', 'new_seller_number', 'new_recharge'
  title TEXT NOT NULL,
  description TEXT,
  user_id UUID,
  related_id UUID,
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.admin_notifications ENABLE ROW LEVEL SECURITY;

-- Only admins can view and manage notifications
CREATE POLICY "Admins can view all notifications"
ON public.admin_notifications
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update notifications"
ON public.admin_notifications
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete notifications"
ON public.admin_notifications
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow system to insert notifications
CREATE POLICY "System can insert notifications"
ON public.admin_notifications
FOR INSERT
WITH CHECK (true);

-- Create trigger function to notify admin when new user signs up
CREATE OR REPLACE FUNCTION public.notify_admin_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.admin_notifications (type, title, description, user_id)
  VALUES (
    'new_user',
    'نوی کارکوونکی ثبت شو',
    'نوم: ' || COALESCE(NEW.full_name, 'نامعلوم'),
    NEW.user_id
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new user signup
CREATE TRIGGER on_new_user_notify_admin
AFTER INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.notify_admin_new_user();

-- Create trigger function to notify admin when new seller number is submitted
CREATE OR REPLACE FUNCTION public.notify_admin_new_seller()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_name TEXT;
BEGIN
  SELECT full_name INTO user_name FROM public.profiles WHERE user_id = NEW.user_id;
  
  INSERT INTO public.admin_notifications (type, title, description, user_id, related_id)
  VALUES (
    'new_seller_number',
    'نوی Seller نمبر ثبت شو',
    'نمبر: ' || NEW.phone_number || ' - کارکوونکی: ' || COALESCE(user_name, 'نامعلوم'),
    NEW.user_id,
    NEW.id
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new seller number
CREATE TRIGGER on_new_seller_number_notify_admin
AFTER INSERT ON public.seller_numbers
FOR EACH ROW
EXECUTE FUNCTION public.notify_admin_new_seller();

-- Create trigger function to notify admin when new recharge request
CREATE OR REPLACE FUNCTION public.notify_admin_new_recharge()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_name TEXT;
BEGIN
  SELECT full_name INTO user_name FROM public.profiles WHERE user_id = NEW.user_id;
  
  INSERT INTO public.admin_notifications (type, title, description, user_id, related_id)
  VALUES (
    'new_recharge',
    'نوې ریچارج غوښتنه',
    'مقدار: ' || NEW.amount || ' افغانی - کارکوونکی: ' || COALESCE(user_name, 'نامعلوم'),
    NEW.user_id,
    NEW.id
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new recharge request
CREATE TRIGGER on_new_recharge_notify_admin
AFTER INSERT ON public.recharge_requests
FOR EACH ROW
EXECUTE FUNCTION public.notify_admin_new_recharge();

-- Enable realtime for admin_notifications
ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_notifications;