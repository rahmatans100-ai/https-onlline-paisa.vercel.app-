import { MessageCircle } from 'lucide-react';

const WHATSAPP_NUMBER = '+93700000000';
const WHATSAPP_MESSAGE = 'سلام! زه آنلاین ګټه سره مرسته غواړم';

const WhatsAppButton = () => {
  const handleClick = () => {
    const encodedMessage = encodeURIComponent(WHATSAPP_MESSAGE);
    const cleanNumber = WHATSAPP_NUMBER.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanNumber}?text=${encodedMessage}`, '_blank');
  };

  return (
    <button
      onClick={handleClick}
      className="fixed bottom-6 left-6 z-50 w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20BA5C] shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center animate-bounce hover:animate-none"
      aria-label="واټساپ ته پیغام واستوئ"
    >
      <MessageCircle className="w-7 h-7 text-white fill-white" />
    </button>
  );
};

export default WhatsAppButton;
