import { Card, CardContent } from '@/components/ui/card';
import { Megaphone } from 'lucide-react';

interface Offer {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  created_at: string;
}

interface OfferCardProps {
  offer: Offer;
}

const OfferCard = ({ offer }: OfferCardProps) => {
  return (
    <Card className="card-shadow overflow-hidden animate-fade-in">
      {offer.image_url && (
        <div className="h-32 bg-gradient-to-r from-primary/20 to-secondary/20">
          <img 
            src={offer.image_url} 
            alt={offer.title} 
            className="w-full h-full object-cover"
          />
        </div>
      )}
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full gradient-warm flex items-center justify-center shrink-0">
            <Megaphone className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-foreground mb-1">{offer.title}</h3>
            {offer.description && (
              <p className="text-sm text-muted-foreground line-clamp-3">
                {offer.description}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-2">
              {new Date(offer.created_at).toLocaleDateString('fa-AF')}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OfferCard;
