import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ArrowRight, Smartphone, Wallet, CheckCircle, Clock, XCircle } from 'lucide-react';

const Recharge = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();

  const [phoneNumber, setPhoneNumber] = useState('');
  const [amount, setAmount] = useState('');

  // Fetch user's recharge requests
  const { data: rechargeRequests, isLoading } = useQuery({
    queryKey: ['recharge-requests', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('recharge_requests')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Check if user has pending recharge request
  const hasPendingRequest = rechargeRequests?.some(r => r.status === 'pending');

  // Submit recharge request
  const submitRechargeMutation = useMutation({
    mutationFn: async ({ phone, amt }: { phone: string; amt: number }) => {
      if ((profile?.balance || 0) < amt) {
        throw new Error('بیلانس کافي نه دی');
      }

      // Check for pending request
      const { data: pending } = await supabase
        .from('recharge_requests')
        .select('id')
        .eq('user_id', user?.id)
        .eq('status', 'pending')
        .limit(1);
      
      if (pending && pending.length > 0) {
        throw new Error('تاسو مخکې یوه غوښتنه لرئ چې تر اوسه تایید شوې نه ده');
      }

      const { error } = await supabase.from('recharge_requests').insert({
        user_id: user?.id,
        phone_number: phone,
        amount: amt,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('غوښتنه بریالي واستول شوه!');
      setPhoneNumber('');
      setAmount('');
      queryClient.invalidateQueries({ queryKey: ['recharge-requests'] });
    },
    onError: (error: Error) => {
      toast.error(error.message || 'تېروتنه وشوه');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!phoneNumber.trim()) {
      toast.error('مهرباني وکړئ نمبر ولیکئ');
      return;
    }
    
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) {
      toast.error('مهرباني وکړئ سم مقدار ولیکئ');
      return;
    }

    if ((profile?.balance || 0) < amt) {
      toast.error('ستاسو بیلانس کافي نه دی');
      return;
    }

    submitRechargeMutation.mutate({ phone: phoneNumber, amt });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return (
          <span className="flex items-center gap-1 text-success text-sm">
            <CheckCircle className="w-4 h-4" />
            بشپړ
          </span>
        );
      case 'rejected':
        return (
          <span className="flex items-center gap-1 text-destructive text-sm">
            <XCircle className="w-4 h-4" />
            رد شوی
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-warning text-sm">
            <Clock className="w-4 h-4" />
            انتظار
          </span>
        );
    }
  };

  const quickAmounts = [50, 100, 200, 500];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-secondary p-6 rounded-b-[2rem]">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            className="text-white hover:bg-white/20"
          >
            <ArrowRight className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">موبایل ریچارج</h1>
            <p className="text-white/70 text-sm">د بیلانس څخه ریچارج وکړئ</p>
          </div>
        </div>

        {/* Balance Display */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Wallet className="w-8 h-8 text-white" />
              <div>
                <p className="text-white/70 text-sm">اوسنی بیلانس</p>
                <p className="text-white font-bold text-xl">
                  {profile?.balance?.toLocaleString() || '0'} افغانی
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="p-6 space-y-6">
        {/* Recharge Form */}
        <Card className="card-shadow animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-secondary" />
              نوې ریچارج غوښتنه
            </CardTitle>
          </CardHeader>
          <CardContent>
            {hasPendingRequest ? (
              <div className="p-4 rounded-lg bg-warning/10 border border-warning/30 text-center">
                <p className="text-warning font-medium mb-2">⏳ تاسو مخکې یوه غوښتنه لرئ</p>
                <p className="text-sm text-muted-foreground">
                  تر هغه چې اوسنۍ غوښتنه تایید نه شي، نوې غوښتنه نه شئ لېږلی
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">موبایل نمبر</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="07XXXXXXXX"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="text-right"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">مقدار (افغانی)</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="مقدار ولیکئ"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-right"
                  />
                </div>

                {/* Quick Amount Buttons */}
                <div className="flex flex-wrap gap-2">
                  {quickAmounts.map((amt) => (
                    <Button
                      key={amt}
                      type="button"
                      variant="outline"
                      onClick={() => setAmount(amt.toString())}
                      className="flex-1"
                    >
                      {amt} افغانی
                    </Button>
                  ))}
                </div>

                <Button
                  type="submit"
                  className="w-full gradient-secondary"
                  disabled={submitRechargeMutation.isPending}
                >
                  {submitRechargeMutation.isPending ? 'انتظار...' : 'غوښتنه واستوئ'}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>

        {/* Previous Requests */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold">پخوانۍ غوښتنې</h2>

          {isLoading ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 mx-auto border-4 border-secondary/30 border-t-secondary rounded-full animate-spin" />
            </div>
          ) : rechargeRequests?.length === 0 ? (
            <Card className="text-center py-8">
              <p className="text-muted-foreground">تاسو تر اوسه کومه غوښتنه نه ده واستولې</p>
            </Card>
          ) : (
            rechargeRequests?.map((item, index) => (
              <Card
                key={item.id}
                className="card-shadow animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-bold">{item.phone_number}</p>
                      <p className="text-lg text-secondary font-bold">
                        {item.amount} افغانی
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.created_at).toLocaleDateString('fa-AF')}
                      </p>
                    </div>
                    {getStatusBadge(item.status)}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default Recharge;
