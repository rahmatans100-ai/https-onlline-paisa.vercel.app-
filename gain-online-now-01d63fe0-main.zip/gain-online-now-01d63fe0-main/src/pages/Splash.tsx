import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const Splash = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  useEffect(() => {
    if (loading) return;

    const timer = setTimeout(() => {
      if (user) {
        navigate('/dashboard');
      } else {
        navigate('/auth');
      }
    }, 2500);

    return () => clearTimeout(timer);
  }, [user, loading, navigate]);

  return (
    <div className="min-h-screen gradient-primary flex flex-col items-center justify-center">
      <div className="animate-scale-in text-center">
        {/* Logo */}
        <div className="w-32 h-32 mx-auto mb-8 rounded-full bg-white/20 backdrop-blur-lg flex items-center justify-center animate-pulse-glow">
          <span className="text-6xl">💰</span>
        </div>

        {/* App Name */}
        <h1 className="text-5xl font-bold text-white mb-4 animate-fade-in">
          آنلاین ګټه
        </h1>

        {/* Tagline */}
        <p className="text-xl text-white/80 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          خپل پیسې پورته کړئ
        </p>

        {/* Loading Animation */}
        <div className="mt-12 flex gap-2 justify-center">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-3 h-3 rounded-full bg-white animate-bounce"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Splash;
