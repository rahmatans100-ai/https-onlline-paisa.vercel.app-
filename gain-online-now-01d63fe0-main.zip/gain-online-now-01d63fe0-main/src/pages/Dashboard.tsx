import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import {
  User,
  Wallet,
  Phone,
  Gift,
  LogOut,
  Smartphone,
  History,
  Settings,
  Shield,
  Megaphone,
} from 'lucide-react';
import WhatsAppButton from '@/components/WhatsAppButton';
import OfferCard from '@/components/OfferCard';

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, signOut, isAdmin } = useAuth();
  const { data: profile, isLoading } = useProfile();

  // Fetch active offers
  const { data: offers } = useQuery({
    queryKey: ['active-offers'],
    queryFn: async () => {
      const { data } = await supabase
        .from('offers')
        .select('*')
        .eq('is_active', true)
        .order('priority', { ascending: false })
        .order('created_at', { ascending: false });
      return data;
    },
  });

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen gradient-primary flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 border-4 border-white/30 border-t-white rounded-full animate-spin" />
          <p className="text-white text-lg">لوډ کېږي...</p>
        </div>
      </div>
    );
  }

  const menuItems = [
    {
      icon: Phone,
      title: 'Seller نمبر ثبت',
      description: 'خپل Seller نمبر ثبت کړئ',
      path: '/seller-number',
      gradient: 'gradient-primary',
    },
    {
      icon: Smartphone,
      title: 'موبایل ریچارج',
      description: 'د بیلانس څخه ریچارج وکړئ',
      path: '/recharge',
      gradient: 'gradient-secondary',
    },
    {
      icon: Gift,
      title: 'Referral سیستم',
      description: 'ملګري راوکاږئ، بونس ترلاسه کړئ',
      path: '/referral',
      gradient: 'gradient-success',
    },
    {
      icon: History,
      title: 'د پیسو تاریخچه',
      description: 'ټولې مالي فعالیتونه وګورئ',
      path: '/transactions',
      gradient: 'gradient-warm',
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-primary p-6 pb-24 rounded-b-[2rem]">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-white/70 text-sm">خوش آمدید</p>
              <h2 className="text-white font-bold text-lg">{profile?.full_name || 'کارکوونکی'}</h2>
            </div>
          </div>
          <div className="flex gap-2">
            {isAdmin && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate('/admin')}
                className="text-white hover:bg-white/20"
              >
                <Shield className="w-5 h-5" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/profile')}
              className="text-white hover:bg-white/20"
            >
              <Settings className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleLogout}
              className="text-white hover:bg-white/20"
            >
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>

        {/* Balance Card */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white/70 text-sm mb-1">اوسنی بیلانس</p>
                <h1 className="text-4xl font-bold text-white">
                  {profile?.balance?.toLocaleString() || '0'}
                  <span className="text-lg mr-2">افغانی</span>
                </h1>
              </div>
              <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center">
                <Wallet className="w-8 h-8 text-white" />
              </div>
            </div>

            {profile?.referral_code && (
              <div className="mt-4 pt-4 border-t border-white/20">
                <p className="text-white/70 text-sm">ستاسو Referral کوډ</p>
                <p className="text-white font-bold text-xl tracking-wider">{profile.referral_code}</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Menu Grid */}
      <div className="px-6 -mt-12">
        <div className="grid grid-cols-2 gap-4">
          {menuItems.map((item, index) => (
            <Card
              key={item.path}
              className="cursor-pointer hover:scale-105 transition-transform duration-200 card-shadow animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
              onClick={() => navigate(item.path)}
            >
              <CardContent className="p-4 text-center">
                <div className={`w-14 h-14 mx-auto mb-3 rounded-xl ${item.gradient} flex items-center justify-center`}>
                  <item.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-bold text-foreground mb-1">{item.title}</h3>
                <p className="text-xs text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Offers Section */}
      <div className="px-6 mt-6">
        <div className="flex items-center gap-2 mb-3">
          <Megaphone className="w-5 h-5 text-primary" />
          <h3 className="font-bold text-foreground">وړاندیزونه او اعلانونه</h3>
        </div>
        {offers && offers.length > 0 ? (
          <div className="space-y-4">
            {offers.map((offer: any) => (
              <OfferCard key={offer.id} offer={offer} />
            ))}
          </div>
        ) : (
          <Card className="card-shadow">
            <CardContent className="p-6 text-center">
              <Megaphone className="w-12 h-12 mx-auto text-muted-foreground/50 mb-2" />
              <p className="text-muted-foreground">اوس مهال کوم وړاندیز نشته</p>
              <p className="text-xs text-muted-foreground mt-1">نوي وړاندیزونه به دلته ښکاره شي</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Quick Stats */}
      <div className="px-6 mt-6 pb-6">
        <Card className="card-shadow">
          <CardContent className="p-4">
            <h3 className="font-bold text-foreground mb-3">چټک معلومات</h3>
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-primary">0</p>
                <p className="text-xs text-muted-foreground">ثبت شوي نمبرونه</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-secondary">0</p>
                <p className="text-xs text-muted-foreground">ریچارجونه</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-accent">0</p>
                <p className="text-xs text-muted-foreground">Referrals</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <WhatsAppButton />
    </div>
  );
};

export default Dashboard;
