import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { ArrowRight, Gift, Copy, Share2, Users, CheckCircle } from 'lucide-react';

const Referral = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data: profile } = useProfile();

  // Fetch referral stats
  const { data: referralStats } = useQuery({
    queryKey: ['referral-stats', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return { count: 0, totalBonus: 0 };
      
      const { data, error } = await supabase
        .from('referrals')
        .select('bonus_amount')
        .eq('referrer_id', profile.id)
        .eq('status', 'completed');
      
      if (error) throw error;
      
      const totalBonus = data?.reduce((sum, r) => sum + Number(r.bonus_amount), 0) || 0;
      return { count: data?.length || 0, totalBonus };
    },
    enabled: !!profile?.id,
  });

  // Fetch referred users
  const { data: referredUsers } = useQuery({
    queryKey: ['referred-users', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return [];
      
      const { data, error } = await supabase
        .from('referrals')
        .select(`
          id,
          bonus_amount,
          created_at,
          referred:referred_id(full_name)
        `)
        .eq('referrer_id', profile.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
    enabled: !!profile?.id,
  });

  const handleCopyCode = () => {
    if (profile?.referral_code) {
      navigator.clipboard.writeText(profile.referral_code);
      toast.success('کوډ کاپي شو!');
    }
  };

  const handleShare = async () => {
    if (profile?.referral_code) {
      const text = `آنلاین ګټه - خپلې پیسې پورته کړئ! زما referral کوډ: ${profile.referral_code}`;
      
      if (navigator.share) {
        try {
          await navigator.share({ text });
        } catch (err) {
          handleCopyCode();
        }
      } else {
        handleCopyCode();
      }
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-success p-6 rounded-b-[2rem]">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            className="text-white hover:bg-white/20"
          >
            <ArrowRight className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">Referral سیستم</h1>
            <p className="text-white/70 text-sm">ملګري راوکاږئ، 5 افغانی بونس ترلاسه کړئ</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Referral Code Card */}
        <Card className="card-shadow animate-fade-in overflow-hidden">
          <div className="gradient-success p-6 text-center">
            <Gift className="w-16 h-16 mx-auto text-white mb-4" />
            <h2 className="text-white text-xl font-bold mb-2">ستاسو Referral کوډ</h2>
            <div className="bg-white/20 backdrop-blur-lg rounded-xl p-4">
              <p className="text-3xl font-bold text-white tracking-widest">
                {profile?.referral_code || '---'}
              </p>
            </div>
            <p className="text-white/80 mt-3 text-sm">
              هر راجع شوی کارکوونکی = <span className="font-bold text-lg">5 افغانی</span> بونس
            </p>
          </div>
          <CardContent className="p-4">
            <div className="flex gap-3">
              <Button
                onClick={handleCopyCode}
                className="flex-1 gradient-primary"
                variant="default"
              >
                <Copy className="w-4 h-4 ml-2" />
                کاپي
              </Button>
              <Button
                onClick={handleShare}
                className="flex-1 gradient-secondary"
                variant="default"
              >
                <Share2 className="w-4 h-4 ml-2" />
                شریکول
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <Card className="card-shadow animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <CardHeader>
            <CardTitle>ستاسو Referral احصایې</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="p-4 rounded-xl gradient-primary text-white">
                <p className="text-3xl font-bold">{referralStats?.count || 0}</p>
                <p className="text-sm text-white/80">ټول راجع شوي</p>
              </div>
              <div className="p-4 rounded-xl gradient-success text-white">
                <p className="text-3xl font-bold">{referralStats?.totalBonus || 0}</p>
                <p className="text-sm text-white/80">ترلاسه شوی بونس</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Referred Users List */}
        {referredUsers && referredUsers.length > 0 && (
          <Card className="card-shadow animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5 text-success" />
                راجع شوي کارکوونکي
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {referredUsers.map((item: any, index) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted animate-fade-in"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full gradient-success flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium">{item.referred?.full_name || 'کارکوونکی'}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.created_at).toLocaleDateString('fa-AF')}
                      </p>
                    </div>
                  </div>
                  <span className="text-success font-bold">+{item.bonus_amount} افغانی</span>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* How it works */}
        <Card className="card-shadow animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-success" />
              دا څنګه کار کوي؟
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center shrink-0">
                <span className="text-white font-bold">۱</span>
              </div>
              <div>
                <h3 className="font-bold">کوډ شریک کړئ</h3>
                <p className="text-sm text-muted-foreground">
                  خپل Referral کوډ له ملګرو سره شریک کړئ
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full gradient-secondary flex items-center justify-center shrink-0">
                <span className="text-white font-bold">۲</span>
              </div>
              <div>
                <h3 className="font-bold">ملګری ثبت کیږي</h3>
                <p className="text-sm text-muted-foreground">
                  کله چې ملګری ستاسو کوډ سره ثبت شي
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-full gradient-success flex items-center justify-center shrink-0">
                <span className="text-white font-bold">۳</span>
              </div>
              <div>
                <h3 className="font-bold">5 افغانی بونس!</h3>
                <p className="text-sm text-muted-foreground">
                  تاسو سمدستي 5 افغانی بونس ترلاسه کوئ
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Referral;
