import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, History, TrendingUp, TrendingDown, Gift } from 'lucide-react';

const Transactions = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { data: transactions, isLoading } = useQuery({
    queryKey: ['transactions', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'add_balance':
        return <TrendingUp className="w-5 h-5 text-success" />;
      case 'recharge':
        return <TrendingDown className="w-5 h-5 text-destructive" />;
      case 'referral_bonus':
        return <Gift className="w-5 h-5 text-primary" />;
      default:
        return <History className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'add_balance':
        return 'بیلانس اضافه';
      case 'recharge':
        return 'ریچارج';
      case 'referral_bonus':
        return 'Referral بونس';
      default:
        return type;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-success';
      case 'rejected':
        return 'text-destructive';
      default:
        return 'text-warning';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-warm p-6 rounded-b-[2rem]">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            className="text-white hover:bg-white/20"
          >
            <ArrowRight className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">د پیسو تاریخچه</h1>
            <p className="text-white/70 text-sm">ټولې مالي فعالیتونه</p>
          </div>
        </div>
      </div>

      <div className="p-6">
        {isLoading ? (
          <div className="text-center py-8">
            <div className="w-8 h-8 mx-auto border-4 border-warning/30 border-t-warning rounded-full animate-spin" />
          </div>
        ) : transactions?.length === 0 ? (
          <Card className="text-center py-12">
            <History className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">تاسو تر اوسه کومه فعالیت نه لرئ</p>
          </Card>
        ) : (
          <div className="space-y-3">
            {transactions?.map((item, index) => (
              <Card
                key={item.id}
                className="card-shadow animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center">
                      {getTypeIcon(item.type)}
                    </div>
                    <div className="flex-1">
                      <p className="font-bold">{getTypeLabel(item.type)}</p>
                      {item.description && (
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        {new Date(item.created_at).toLocaleDateString('fa-AF')}
                      </p>
                    </div>
                    <div className="text-left">
                      <p
                        className={`font-bold text-lg ${
                          item.type === 'recharge' ? 'text-destructive' : 'text-success'
                        }`}
                      >
                        {item.type === 'recharge' ? '-' : '+'}
                        {item.amount}
                      </p>
                      <p className={`text-xs ${getStatusColor(item.status)}`}>
                        {item.status === 'completed'
                          ? 'بشپړ'
                          : item.status === 'rejected'
                          ? 'رد شوی'
                          : 'انتظار'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Transactions;
