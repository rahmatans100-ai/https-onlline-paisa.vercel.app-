import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { ArrowRight, Phone, Key, CheckCircle, Clock, XCircle, Send } from 'lucide-react';

const SellerNumber = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const [phoneNumber, setPhoneNumber] = useState('');
  const [code, setCode] = useState('');
  const [codeDialogOpen, setCodeDialogOpen] = useState(false);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);

  // Fetch user's seller numbers
  const { data: sellerNumbers, isLoading } = useQuery({
    queryKey: ['seller-numbers', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seller_numbers')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Check if user has pending seller number
  const hasPendingNumber = sellerNumbers?.some(
    n => n.status === 'pending' || (n.status === 'approved' && n.code_status !== 'approved')
  );

  // Real-time subscription for seller_numbers updates
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('seller-numbers-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'seller_numbers',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const newData = payload.new as any;
          if (newData.code_status === 'can_enter') {
            toast.success('🎉 اډمین اجازه ورکړه! اوس کوډ داخل کړئ');
            setSelectedSellerId(newData.id);
            setCodeDialogOpen(true);
          } else if (newData.code_status === 'approved') {
            toast.success(`✅ کوډ تایید شو! ${newData.balance_added} افغانی اضافه شو`);
          }
          queryClient.invalidateQueries({ queryKey: ['seller-numbers'] });
          queryClient.invalidateQueries({ queryKey: ['profile'] });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, queryClient]);

  // Submit phone number
  const submitPhoneMutation = useMutation({
    mutationFn: async (phone: string) => {
      // Check for pending number
      const { data: pending } = await supabase
        .from('seller_numbers')
        .select('id, status, code_status')
        .eq('user_id', user?.id)
        .or('status.eq.pending,and(status.eq.approved,code_status.neq.approved)')
        .limit(1);
      
      if (pending && pending.length > 0) {
        throw new Error('تاسو مخکې یو نمبر لرئ چې تر اوسه بشپړ شوی نه دی');
      }

      // Check if phone number already exists
      const { data: existing } = await supabase
        .from('seller_numbers')
        .select('id')
        .eq('phone_number', phone)
        .limit(1);
      
      if (existing && existing.length > 0) {
        throw new Error('دا نمبر مخکې ثبت شوی دی');
      }

      const { error } = await supabase.from('seller_numbers').insert({
        user_id: user?.id,
        phone_number: phone,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('نمبر بریالي ثبت شو! د اډمین تایید ته انتظار وکړئ');
      setPhoneNumber('');
      queryClient.invalidateQueries({ queryKey: ['seller-numbers'] });
    },
    onError: (error: Error) => {
      toast.error(error.message || 'تېروتنه وشوه، بیا هڅه وکړئ');
    },
  });

  // Submit code
  const submitCodeMutation = useMutation({
    mutationFn: async ({ id, codeValue }: { id: string; codeValue: string }) => {
      const { error } = await supabase
        .from('seller_numbers')
        .update({ code: codeValue, code_status: 'pending' })
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('کوډ بریالي واستول شو! د تایید لپاره انتظار وکړئ');
      setCode('');
      setCodeDialogOpen(false);
      setSelectedSellerId(null);
      queryClient.invalidateQueries({ queryKey: ['seller-numbers'] });
    },
    onError: () => {
      toast.error('تېروتنه وشوه، بیا هڅه وکړئ');
    },
  });

  const handleSubmitPhone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber.trim()) {
      toast.error('مهرباني وکړئ نمبر ولیکئ');
      return;
    }
    submitPhoneMutation.mutate(phoneNumber);
  };

  const handleOpenCodeDialog = (id: string) => {
    setSelectedSellerId(id);
    setCodeDialogOpen(true);
  };

  const handleSubmitCode = () => {
    if (!code.trim()) {
      toast.error('مهرباني وکړئ کوډ ولیکئ');
      return;
    }
    if (selectedSellerId) {
      submitCodeMutation.mutate({ id: selectedSellerId, codeValue: code });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return (
          <span className="flex items-center gap-1 text-success text-sm">
            <CheckCircle className="w-4 h-4" />
            تایید شوی
          </span>
        );
      case 'rejected':
        return (
          <span className="flex items-center gap-1 text-destructive text-sm">
            <XCircle className="w-4 h-4" />
            رد شوی
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-warning text-sm">
            <Clock className="w-4 h-4" />
            انتظار
          </span>
        );
    }
  };

  const getCodeStatusBadge = (status: string) => {
    switch (status) {
      case 'can_enter':
        return (
          <span className="text-primary text-sm font-medium">کوډ داخل کړئ</span>
        );
      case 'approved':
        return (
          <span className="flex items-center gap-1 text-success text-sm">
            <CheckCircle className="w-4 h-4" />
            کوډ تایید شو
          </span>
        );
      case 'rejected':
        return (
          <span className="flex items-center gap-1 text-destructive text-sm">
            <XCircle className="w-4 h-4" />
            کوډ رد شو
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-muted-foreground text-sm">
            <Clock className="w-4 h-4" />
            د اجازې انتظار
          </span>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Code Entry Dialog */}
      <Dialog open={codeDialogOpen} onOpenChange={setCodeDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-xl">
              <Key className="w-8 h-8 mx-auto mb-2 text-primary" />
              کوډ داخل کړئ
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="p-4 rounded-lg bg-success/10 text-center">
              <p className="text-success font-medium">
                🎉 اډمین اجازه ورکړه! اوس خپل کوډ داخل کړئ
              </p>
            </div>
            <div className="space-y-2">
              <Label>کوډ</Label>
              <Input
                placeholder="خپل کوډ دلته ولیکئ"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="text-center text-2xl tracking-widest"
              />
            </div>
            <Button
              onClick={handleSubmitCode}
              className="w-full gradient-primary py-6"
              disabled={submitCodeMutation.isPending}
            >
              {submitCodeMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  انتظار...
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Send className="w-5 h-5" />
                  کوډ واستوئ
                </span>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="gradient-primary p-6 rounded-b-[2rem]">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            className="text-white hover:bg-white/20"
          >
            <ArrowRight className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">Seller نمبر ثبت</h1>
            <p className="text-white/70 text-sm">خپل موبایل نمبر دلته ثبت کړئ</p>
          </div>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* New Number Form */}
        <Card className="card-shadow animate-fade-in">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-primary" />
              نوی نمبر ثبت کړئ
            </CardTitle>
          </CardHeader>
          <CardContent>
            {hasPendingNumber ? (
              <div className="p-4 rounded-lg bg-warning/10 border border-warning/30 text-center">
                <p className="text-warning font-medium mb-2">⏳ تاسو مخکې یو نمبر لرئ</p>
                <p className="text-sm text-muted-foreground">
                  تر هغه چې اوسنی نمبر بشپړ نه شي، نوی نمبر نه شئ ثبتولی
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitPhone} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">موبایل نمبر</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="07XXXXXXXX"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className="text-right"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full gradient-primary"
                  disabled={submitPhoneMutation.isPending}
                >
                  {submitPhoneMutation.isPending ? 'انتظار...' : 'ثبت کول'}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>

        {/* Existing Numbers */}
        <div className="space-y-4">
          <h2 className="text-lg font-bold">ستاسو ثبت شوي نمبرونه</h2>

          {isLoading ? (
            <div className="text-center py-8">
              <div className="w-8 h-8 mx-auto border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : sellerNumbers?.length === 0 ? (
            <Card className="text-center py-8">
              <p className="text-muted-foreground">تاسو تر اوسه کوم نمبر نه دی ثبت کړی</p>
            </Card>
          ) : (
            sellerNumbers?.map((item, index) => (
              <Card
                key={item.id}
                className="card-shadow animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <Phone className="w-5 h-5 text-primary" />
                      <span className="font-bold text-lg">{item.phone_number}</span>
                    </div>
                    {getStatusBadge(item.status)}
                  </div>

                  <div className="border-t pt-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">د کوډ حالت:</span>
                      {getCodeStatusBadge(item.code_status)}
                    </div>

                    {item.code_status === 'can_enter' && (
                      <Button
                        onClick={() => handleOpenCodeDialog(item.id)}
                        className="w-full mt-3 gradient-secondary"
                      >
                        <Key className="w-4 h-4 ml-2" />
                        کوډ داخل کړئ
                      </Button>
                    )}

                    {item.code_status === 'approved' && item.balance_added && (
                      <div className="mt-3 p-3 rounded-lg bg-success/10">
                        <p className="text-success font-medium">
                          ✅ {item.balance_added} افغانی ستاسو حساب ته اضافه شو!
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default SellerNumber;
