import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { User, Gift, Phone } from 'lucide-react';
import WhatsAppButton from '@/components/WhatsAppButton';

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [loading, setLoading] = useState(false);

  const { signIn, signUp, user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  // Get referral code from URL if present
  useEffect(() => {
    const refCode = searchParams.get('ref');
    if (refCode) {
      setReferralCode(refCode.toUpperCase());
      setIsLogin(false); // Switch to signup if referral link
    }
  }, [searchParams]);

  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  const validatePhoneNumber = (number: string) => {
    const cleanNumber = number.replace(/[^0-9]/g, '');
    return cleanNumber.length >= 10 && cleanNumber.length <= 15;
  };

  // Generate email from phone number
  const generateEmail = (phone: string) => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    return `${cleanPhone}@onlinegata.app`;
  };

  // Use phone number as password (with prefix for minimum length)
  const generatePassword = (phone: string) => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    return `OG_${cleanPhone}_2024`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (!validatePhoneNumber(phoneNumber)) {
        toast.error('مهرباني وکړئ سم نمبر ولیکئ (لږترلږه 10 عددونه)');
        setLoading(false);
        return;
      }

      const email = generateEmail(phoneNumber);
      const password = generatePassword(phoneNumber);

      if (isLogin) {
        const { error } = await signIn(email, password);
        if (error) {
          if (error.message.includes('Invalid login')) {
            toast.error('دا نمبر ثبت شوی نه دی - لومړی ثبت کړئ');
          } else {
            toast.error(error.message);
          }
        } else {
          toast.success('ننوتل بریالي وو!');
          navigate('/dashboard');
        }
      } else {
        if (!fullName.trim()) {
          toast.error('مهرباني وکړئ خپل نوم ولیکئ');
          setLoading(false);
          return;
        }
        
        const { error } = await signUp(email, password, fullName, phoneNumber, referralCode);
        if (error) {
          if (error.message.includes('already registered')) {
            toast.error('دا نمبر مخکې ثبت شوی دی - ننوځئ');
          } else {
            toast.error(error.message);
          }
        } else {
          toast.success('حساب بریالي جوړ شو!');
          navigate('/dashboard');
        }
      }
    } catch (err) {
      toast.error('یوه تېروتنه وشوه');
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen gradient-primary flex items-center justify-center p-4">
      <Card className="w-full max-w-md glass-effect border-0 card-shadow animate-scale-in">
        <CardHeader className="text-center pb-2">
          <div className="w-24 h-24 mx-auto mb-4 rounded-full gradient-secondary flex items-center justify-center shadow-lg">
            <span className="text-5xl">💰</span>
          </div>
          <CardTitle className="text-4xl font-bold text-gradient">
            آنلاین ګټه
          </CardTitle>
          <p className="text-muted-foreground mt-2 text-lg">
            {isLogin ? 'خپل حساب ته ننوځئ' : 'نوی حساب جوړ کړئ'}
          </p>
        </CardHeader>

        <CardContent className="pt-4">
          <form onSubmit={handleSubmit} className="space-y-5">
            {!isLogin && (
              <div className="space-y-2 animate-fade-in">
                <Label htmlFor="fullName" className="flex items-center gap-2 text-base">
                  <User className="w-5 h-5" />
                  بشپړ نوم
                </Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="خپل بشپړ نوم ولیکئ"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="text-right h-12 text-lg"
                  required={!isLogin}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="phone" className="flex items-center gap-2 text-base">
                <Phone className="w-5 h-5 text-[#25D366]" />
                موبایل نمبر
              </Label>
              <Input
                id="phone"
                type="tel"
                placeholder="0700000000"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value.replace(/[^0-9+]/g, ''))}
                className="h-12 text-lg"
                required
                dir="ltr"
              />
              <p className="text-xs text-muted-foreground">
                نوټ: همدا نمبر ستاسو حساب پیژني
              </p>
            </div>

            {!isLogin && (
              <div className="space-y-2 animate-fade-in">
                <Label htmlFor="referral" className="flex items-center gap-2 text-base">
                  <Gift className="w-5 h-5 text-accent" />
                  د راجع کولو کوډ (اختیاري)
                </Label>
                <Input
                  id="referral"
                  type="text"
                  placeholder="که کوډ لرئ دلته ولیکئ"
                  value={referralCode}
                  onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                  className="text-right uppercase h-12 text-lg"
                />
              </div>
            )}

            <Button
              type="submit"
              className="w-full gradient-primary text-white font-bold py-7 text-xl hover:opacity-90 transition-opacity rounded-xl shadow-lg"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  انتظار...
                </span>
              ) : isLogin ? (
                'ننوتل'
              ) : (
                'ثبت کول'
              )}
            </Button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary hover:underline font-medium text-lg"
            >
              {isLogin ? 'حساب نه لرئ؟ نوی جوړ کړئ' : 'حساب لرئ؟ ننوځئ'}
            </button>
          </div>
        </CardContent>
      </Card>

      <WhatsAppButton />
    </div>
  );
};

export default Auth;
