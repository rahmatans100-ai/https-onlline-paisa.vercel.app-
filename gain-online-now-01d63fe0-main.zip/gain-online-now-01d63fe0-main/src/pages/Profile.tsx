import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useProfile } from '@/hooks/useProfile';
import { supabase } from '@/integrations/supabase/client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { ArrowRight, User, Mail, Calendar, Edit2, Save } from 'lucide-react';

const Profile = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { data: profile } = useProfile();
  const queryClient = useQueryClient();

  const [isEditing, setIsEditing] = useState(false);
  const [fullName, setFullName] = useState(profile?.full_name || '');

  const updateProfileMutation = useMutation({
    mutationFn: async (name: string) => {
      const { error } = await supabase
        .from('profiles')
        .update({ full_name: name })
        .eq('user_id', user?.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('پروفایل تازه شو!');
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['profile'] });
    },
    onError: () => {
      toast.error('تېروتنه وشوه');
    },
  });

  const handleSave = () => {
    if (!fullName.trim()) {
      toast.error('نوم خالي نه شي کېدی');
      return;
    }
    updateProfileMutation.mutate(fullName);
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="gradient-primary p-6 pb-24 rounded-b-[2rem]">
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate('/dashboard')}
            className="text-white hover:bg-white/20"
          >
            <ArrowRight className="w-6 h-6" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-white">پروفایل</h1>
            <p className="text-white/70 text-sm">خپل معلومات اداره کړئ</p>
          </div>
        </div>

        {/* Avatar */}
        <div className="text-center">
          <div className="w-24 h-24 mx-auto rounded-full bg-white/20 flex items-center justify-center">
            <User className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-white text-xl font-bold mt-4">
            {profile?.full_name || 'کارکوونکی'}
          </h2>
          <p className="text-white/70">{user?.email}</p>
        </div>
      </div>

      <div className="px-6 -mt-12 space-y-6 pb-6">
        {/* Profile Info */}
        <Card className="card-shadow animate-fade-in">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-primary" />
              شخصي معلومات
            </CardTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsEditing(!isEditing)}
            >
              <Edit2 className="w-4 h-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>بشپړ نوم</Label>
              {isEditing ? (
                <div className="flex gap-2">
                  <Input
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="text-right"
                  />
                  <Button
                    onClick={handleSave}
                    disabled={updateProfileMutation.isPending}
                    className="gradient-primary shrink-0"
                  >
                    <Save className="w-4 h-4" />
                  </Button>
                </div>
              ) : (
                <p className="p-3 rounded-lg bg-muted">{profile?.full_name || '---'}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                ایمیل
              </Label>
              <p className="p-3 rounded-lg bg-muted">{user?.email}</p>
            </div>

            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                د ثبت نېټه
              </Label>
              <p className="p-3 rounded-lg bg-muted">
                {profile?.created_at
                  ? new Date(profile.created_at).toLocaleDateString('fa-AF')
                  : '---'}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Account Stats */}
        <Card className="card-shadow animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <CardHeader>
            <CardTitle>حساب احصایې</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl gradient-primary text-white text-center">
                <p className="text-3xl font-bold">{profile?.balance?.toLocaleString() || '0'}</p>
                <p className="text-sm text-white/80">اوسنی بیلانس</p>
              </div>
              <div className="p-4 rounded-xl gradient-secondary text-white text-center">
                <p className="text-3xl font-bold">{profile?.referral_code || '---'}</p>
                <p className="text-sm text-white/80">Referral کوډ</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Logout Button */}
        <Button
          onClick={handleLogout}
          variant="destructive"
          className="w-full py-6 text-lg"
        >
          له حساب څخه وځئ
        </Button>
      </div>
    </div>
  );
};

export default Profile;
